<?php wp_reset_query(); ?><?php

if(is_home() || is_front_page()) : ?>
	<!-- Coluna Principal do Documento -->
			<div id="ifes-doc-coluna-principal">
            
				<!-- Barra de Busca e Caminho de Migalhas de Pão -->
				
				<?php include (TEMPLATEPATH . '/includes/topo-centro.php'); ?>
         
				 	
				<!-- Fim Barra de Busca e Caminho de Migalhas de Pão -->
			
				<!-- Coluna Central do Documento -->
	
	<?php else : ?>

<!-- Coluna Principal do Documento -->
			<div id="ifes-doc-coluna-principal">
				<!-- Barra de Busca e Caminho de Migalhas de Pão -->
				<div id="caminho-e-barra-busca">
				
					<div id="caminho-migalhas" class="breadcrumbs patchway">
						<span class="pathway">
						<?php if(function_exists('bcn_display'))
                        {
                            bcn_display();
                        }?>
                        </span>
                    </div>
<?php get_search_form();?>			
				</div>				
				<!-- Fim Barra de Busca e Caminho de Migalhas de Pão -->
			
				<!-- Coluna Central do Documento -->
<?php endif; ?>