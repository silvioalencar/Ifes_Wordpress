<!-- Topo2 do Centro -->
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('topo2-centro') ) : ?>
			   		<?php endif; ?>	
