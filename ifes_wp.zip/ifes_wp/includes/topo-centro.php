<!-- Topo do Centro -->
	
					<?php if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar('topo-centro') ) : ?>
			   		<?php endif; ?>	
