	</div>
				<!-- Fim da coluna Central do Documento-->			
				<!-- Clear: Colocado para Quebrar com os floats das colunas -->
				<br clear="all">
				<!-- Fim do Clear -->
				 			
			</div>			
			<!-- Fim da Coluna Principal do Documento -->
			
			<!-- Rodape do Documento -->
			<div id="ifes-doc-rodape">
				
<p>© 2009. Instituto Federal de Educação, Ciência e Tecnologia do Espírito Santo.</p>
			</div>			
			<!-- Fim do Rodapé do Documento -->			
		  			  	
		  </div>		  
		  <!-- Fim do Corpo Prinicipal do Documento -->
		  
		</div>
	</div>	
</div>
<!-- Fim do Documento Ifes -->
<!----- Fim da codificação adaptada ---->
<?php wp_footer(); ?>
<script>
    $(function() {
        $( "#menu-pagina-inicial" ).tabs({
           // event: "mouseover",
		   active: <?php echo get_option('item_tab', 0);?>
        });
    });
    </script>

</body>
</html>