<?php get_header(); ?>
<?php get_sidebar('left'); ?>
<?php include (TEMPLATEPATH . '/includes/principal.php'); ?>
<?php get_sidebar('right'); ?>		
<?php get_footer();?>